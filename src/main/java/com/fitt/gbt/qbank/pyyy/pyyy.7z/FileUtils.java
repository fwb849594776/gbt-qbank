package com.fitt.gbt.qbank.pyyy;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FileUtils {

    public static void writeToFile2(String content) {
        try {
            File file = new File("D:\\workspace_self\\gbt-qbank\\src\\main\\java\\com\\fitt\\gbt\\qbank\\pyyy\\pyyy_log.txt");
            //文件不存在时候，主动穿件文件。
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(file, true);
            BufferedWriter bw = new BufferedWriter(fw);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            bw.write("\r\n" + sdf.format(new Date()));
            bw.write("\r\n" + content);
            bw.write("\r\n***********************************");
            bw.close();
            fw.close();

        } catch (Exception e) {
            // TODO: handle exception
        }
    }
}
