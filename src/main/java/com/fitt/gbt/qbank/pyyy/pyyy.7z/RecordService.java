package com.fitt.gbt.qbank.pyyy;

import java.util.ArrayList;
import java.util.List;

/**
 * panyu book
 *
 * @author kuangcl
 */
public class RecordService {
    //	private static final String YY_URL ="http://b.pyrc.com.cn/yy.asp";
    /**
     * 正常预约地址
     */
    private static final String YY_URL = "http://b.pyrc.com.cn/yuyue/yydj.asp";
    //	private static final String YY_URL ="http://b.pyrc.com.cn/yuyue/yydj_t37.asp";

    /**
     * 获取所有预约时间段
     *
     * @return
     */
    public List<String> getTimes() {
        List<String> times = new ArrayList<String>();
        times.add("10:30");
        times.add("15:30");
        times.add("09:30");
        times.add("08:30");
        times.add("14:30");
        return times;
    }

    /**
     * 获取所有可以预约的日期
     *
     * @return
     */
    public List<String> getDays() {
        List<String> days = new ArrayList<String>();

        days.add("2018-6-19");
        days.add("2018-6-20");
        days.add("2018-6-21");
        days.add("2018-6-22");
        //
        //		days.add("2018-6-25");
        //		days.add("2018-6-26");
        //		days.add("2018-6-27");
        //		days.add("2018-6-28");
        //		days.add("2018-6-29");
        return days;
    }

    /**
     * 开始执行预约提交
     *
     * @param mobCode 短信验证码
     * @param cid     身份证号码
     * @param phone   电话
     * @param name    姓名
     * @param picCode 图片验证码
     */
    public void startSubmit(String mobCode, String cid, String phone, String name, String date, String picCode) {
        String xml = "";
        List<String> times = getTimes();
        //while (true) {
            for (int j = 0; j < times.size(); j++) {
                //新番禺接口修改成以下信息了
                xml = HttpRequest.sendGet("http://b.pyrc.com.cn/yuyue/yydj.asp",
                    "B16=技能类人才&B07=" + date + "&B08=" + times.get(j) + "&B01=" + name + "&B02=" + cid
                        + "&picCode=" + picCode + "&B03=" + phone + "&B04=" + mobCode + "&x=59&y=22&method=1&item=3");
                System.out.println(xml);
                //				xml = HttpRequest.sendPost(YY_URL, "B07="+dates.get(i)+"&B08="+times.get(j)
                // +"&B16=技能类人才&B01="+name+"&B02="+cid+"&picCode=5372&B03="+phone+"&B04="+mobCode+"&x=96&y=29&method
                // =1");
                //				xml = HttpRequest.sendPost(YY_URL, "rq="+dates.get(i)+"&sjd="+times.get(j)
                // +"&B01="+name+"&B02="+cid+"&picCode=8831&B03="+phone+"&B04="+mobCode+"&x=96&y=29&method=1");
                if (xml.indexOf("成功") > -1) {
                    //预约成功的返回<script>alert('预约成功，请记录：\n\n预约编号：8233');location.href='cancelyy.asp';</script>
                    FileUtils.writeToFile2(
                        "B16=技能类人才&B07=" + date + "&B08=" + times.get(j) + "&B01=" + name + "&B02=" + cid
                            + "&picCode=CAUMB&B03=" + phone + "&B04=" + mobCode + "&x=59&y=22&method=1&item=3");
                    FileUtils.writeToFile2(xml);
                    System.out.println(xml);
                    //System.exit(0);
                }
            }
        //}
    }
}
