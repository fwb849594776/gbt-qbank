package com.fitt.gbt.qbank.pyyy;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.Map;
import java.util.Properties;

/**
 * 番禺入户预约小程序
 *
 * @author kuangcl
 */
public class RecordInfo5 {

    /**
     * @param args
     */
    public static void main(String[] args) {
        RecordInfo5 rc = new RecordInfo5();
        // 图片验证码
        String picCode = "";
        //短信验证码，预约用户提供
        String mobCode = "163998";
        String cid = "350782198206243016";
        String phone = "13302201596";
        String name = "曹进斌";
        String date = "2018-11-01,2018-10-26,2018-10-25,2018-10-29,2018-10-30,2018-10-31";
        // http://b.pyrc.com.cn/yuyue/clibrary/getmobile
        // .asp?rq=2018-11-01&trnd=13302201596&sName=曹进斌&sId=350782198206243016&picCode=CAUMB&sTime
        // =2018-11-01&item=3
        RecordService rService = new RecordService();
        rService.startSubmit(mobCode, cid, phone, name, date, picCode);

    }

    public static String sendPost(String url, String param) {
        //      PrintWriter out = null;
        OutputStreamWriter out = null;
        BufferedReader in = null;
        String result = "";
        try {
            URL realUrl = new URL(url);
            // 打开和URL之间的连接
            URLConnection conn = realUrl.openConnection();
            // 设置通用的请求属性
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent",
                "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            // 发送POST请求必须设置如下两行
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setRequestProperty("Accept-Charset", "gb2312");
            conn.setRequestProperty("contentType", "gb2312");
            //          conn.addRequestProperty("Cookie",
			// "UM_distinctid=163009e339c102-0958dd34d995ce-4446062d-100200-163009e339d2c1;
			// ASPSESSIONIDQADRASBR=MBNDKEICGEIJDIKOOJDDNKAN");
            conn.addRequestProperty("Cookie",
                "td_cookie=1833927360; UM_distinctid=163009e339c102-0958dd34d995ce-4446062d-100200-163009e339d2c1; "
					+ "ASPSESSIONIDSCCSCTBQ=KMOJCEBACBKJCNHHCGBAGJBB; ASPSESSIONIDSADTCTAR=PIJFPPNACPDDMFKIDPKELBAH");
            // 获取URLConnection对象对应的输出流
            //          out = new PrintWriter(conn.getOutputStream());
            // 发送请求参数
            //          out.print(param);
            out = new OutputStreamWriter(conn.getOutputStream(), "gb2312");
            out.write(param);
            // flush输出流的缓冲
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), "GBK"));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            System.out.println("发送 POST 请求出现异常！" + e);
            e.printStackTrace();
        }
        //使用finally块来关闭输出流、输入流
        finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return result;
    }

    /**
     * 发送邮件通知
     */
    private void sendMailNotice(String content) {
        // 收件人电子邮箱
        String to = "kuangcl@excellence.com.cn";

        // 发件人电子邮箱
        String from = "kuangchenglong@yeah.net";

        // 指定发送邮件的主机为 localhost
        String host = "smtp.yeah.net";

        // 获取系统属性
        Properties properties = System.getProperties();

        // 设置邮件服务器
        properties.setProperty("mail.smtp.host", host);
        properties.put("mail.smtp.auth", "true");
        properties.setProperty("mail.user", "kuangchenglong");
        properties.setProperty("mail.password", "chenglong33");

        // 获取默认session对象
        Session session = Session.getDefaultInstance(properties, new Authenticator() {
            public PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("kuangchenglong", "chenglong33"); //发件人邮件用户名、密码
            }
        });
        try {
            // 创建默认的 MimeMessage 对象
            MimeMessage message = new MimeMessage(session);

            // Set From: 头部头字段
            message.setFrom(new InternetAddress(from));

            // Set To: 头部头字段
            message.addRecipient(Message.RecipientType.TO,
                new InternetAddress(to));

            // Set Subject: 头部头字段
            message.setSubject("有号了");

            // 设置消息体
            message.setText(content);

            // 发送消息
            Transport.send(message);
            System.out.println("Sent message successfully....");
        } catch (MessagingException mex) {
            mex.printStackTrace();
        }
    }

    /**
     * 获取请求参数
     *
     * @param conds
     * @return
     */
    private String getParams(Map conds) {
        StringBuffer param = new StringBuffer();
        //"certificate":perID,"phone":telpNum,"service_item_code":service_item_code,"time":is_free,"predate":apDate,
		// "service_item_name":service_item_name,"address":address,"addressMsg":addressMsg,
		// "addressPhone":addressPhone,"org_code":org_code
        String certificate = "350181199112171766";
        String phone = "18826289967";
        String service_item_code = (String)conds.get("service_item_code");
        String time = (String)conds.get("time");
        String predate = (String)conds.get("predate");
        String service_item_name = "本科（含中级职称）人才引进";
        String address = "天河北路894号（咨询电话：020-38470847）";
        String addressMsg = "天河北路894号（咨询电话：020-38470847）";
        String addressPhone = "37690333";
        String org_code = "G34014976";
        param.append("certificate=").append(certificate);
        param.append("&phone=").append(phone);
        param.append("&service_item_code=").append(service_item_code);
        param.append("&time=").append(time);
        param.append("&predate=").append(predate);
        param.append("&service_item_name=").append(service_item_name);
        param.append("&address=").append(address);
        param.append("&addressMsg=").append(addressMsg);
        param.append("&addressPhone=").append(addressPhone);
        param.append("&org_code=").append(org_code);
        return param.toString();
    }
}
