package com.fitt.gbt.qbank.pyyy;

import javax.script.*;
import java.io.FileReader;
import java.util.List;

/**
 * @author : <a href="mailto:congchun.zcc@gmail.com">congchun.zcc</a>
 * @version : 1.0.0
 * @descripiton : RSA, a suite of routines for performing RSA public-key computations in Java.
 * @since : 2018/10/12
 */
public class AESUtil {
    public static void main(String[] args) {
        invokeExpression();
    }

    public static void invokeExpression() {
        try {
            ScriptEngineManager scriptEngineManager = new ScriptEngineManager();
            ScriptEngine scriptEngine = scriptEngineManager.getEngineByName("javascript");
            String fileName = "AESUtil.js";

            FileReader fileReader = new FileReader(fileName);
            scriptEngine.eval(fileReader);

            if (scriptEngine instanceof Invocable) {
                Invocable invocable = (Invocable)scriptEngine;

                String value = (String)invocable.invokeFunction("getKeyPair", "234", "111", "222");
                System.out.println(value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void printFactoryName() {
        ScriptEngineManager scriptEngineManager = new ScriptEngineManager();
        List<ScriptEngineFactory> factoryList = scriptEngineManager.getEngineFactories();
        for (ScriptEngineFactory factory : factoryList) {
            System.out.println(factory.getNames());
        }
    }
}
