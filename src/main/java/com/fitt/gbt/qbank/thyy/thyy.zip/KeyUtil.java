package com.fitt.gbt.qbank.thyy;

import java.util.ArrayList;
import java.util.List;

public class KeyUtil {
	public static String getModulus(String cookie){
		String url = "http://thzwb.thnet.gov.cn/web/jsp/bsy/appointment.jsp";
		String param = "";
		String result = HttpRequest.sendGet(url, param,cookie);
		//		System.out.println(result);
		int start =result.indexOf("RSAUtils.getKeyPair");
		int end = result.indexOf("RSAUtils.encryptedString");
		String temp = result.substring(start,end).replaceAll("\\s*", "");
		//		System.out.println(temp);
		String modulus = temp.substring(32, temp.length()-15);
		System.out.println("modulus = "+modulus);
		return modulus;
	}

	public static void main(String[] args) {
		////		String url = "http://thzwb.thnet.gov.cn/getWorkDayInfo.action";
		////		String param = "day=20";
		//		String url = "http://thzwb.thnet.gov.cn/web/jsp/bsy/appointment.jsp";
		//		String param = "";
		////		String cookies1 = "JSESSIONID=NyZTh9ZMH4NSMFsnhvL22HXy0hP2BfJKrGL2qnZh9LXp3GnFYWVK!-1085356344; Hm_lvt_29fc8452db501333b0dd91bd1d996e20=1526548171,1526552688,1526569402,1526569479; Hm_lpvt_29fc8452db501333b0dd91bd1d996e20=1526569516";
		//		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
		//		List<String> cookies = getCookies();
		//		String result ="";
		//    	while(true){
		//    		for(int i=0;i<cookies.size();i++){
		//    			result = HttpRequest.sendGet(url, param,cookies.get(i));
		////    			System.out.println(result.indexOf("new RSAUtils.getKeyPair(\"10001\", \"\"\, "));
		//        		System.out.println(cookies.get(i));
		//        		System.out.println(result);
		//        		int start =result.indexOf("RSAUtils.getKeyPair");
		//        		int end = result.indexOf("RSAUtils.encryptedString");
		//        		String temp = result.substring(start,end).replaceAll("\\s*", "");
		//        		System.out.println(temp);
		//        		String key = temp.substring(32, temp.length()-15);
		//    		}
		//			if("00:06".equals(sdf.format(new Date()))){
		//				System.exit(0);
		//			}
		//			try {
		//				Thread.sleep(1000*60*10);
		//			} catch (InterruptedException e) {
		//				e.printStackTrace();
		//			}
		//		}
		System.out.println(getModulus("JSESSIONID=6884D77736A59409AF0E27374AAF656B; Hm_lvt_e7d4cfc620a3c5671317bc61d90cfb31=1539236347,1539236359,1539246302,1539261503; Hm_lpvt_e7d4cfc620a3c5671317bc61d90cfb31=1539261506"));
	}
	/**
	 * 需要维持在线昨天的账号cookie
	 * @return
	 */
	private static List<String> getCookies(){
		List<String> cookies = new ArrayList<String>();
		//		叶昌果
		cookies.add("JSESSIONID=6884D77736A59409AF0E27374AAF656B; Hm_lvt_e7d4cfc620a3c5671317bc61d90cfb31=1539236347,1539236359,1539246302,1539261503; Hm_lpvt_e7d4cfc620a3c5671317bc61d90cfb31=1539261506");
		//黄文敏
		//		cookies.add("JSESSIONID=E3CC84962D07A739298025AD87485079; Hm_lvt_e7d4cfc620a3c5671317bc61d90cfb31=1530500059,1530534554,1530536906,1530537063; Hm_lpvt_e7d4cfc620a3c5671317bc61d90cfb31=1530537086");
		//		//朱静
		//		cookies.add("JSESSIONID=0BF3B46DC4AC0445C66AA5A5AB4FBB05; Hm_lvt_e7d4cfc620a3c5671317bc61d90cfb31=1529078273,1529412824,1529672349,1529941088; Hm_lpvt_e7d4cfc620a3c5671317bc61d90cfb31=1529941122");
		//		//账号kcl33
		//		cookies.add("JSESSIONID=CA73E52AA5892379EC87C743A9347B8C; Hm_lvt_e7d4cfc620a3c5671317bc61d90cfb31=1528905483,1529077343,1529677228,1529941247; Hm_lpvt_e7d4cfc620a3c5671317bc61d90cfb31=1529941305");
		//		//账号kcl33
		//		cookies.add("td_cookie=1654939224; JSESSIONID=42029A0AAC8C7CBB238F0740E1E91153; Hm_lvt_e7d4cfc620a3c5671317bc61d90cfb31=1527850167,1527863202,1527863648,1527864626; Hm_lpvt_e7d4cfc620a3c5671317bc61d90cfb31=1527864669");
		return cookies;
	}

	public static String getKey(){
		String url = "http://thzwb.thnet.gov.cn/web/jsp/bsy/appointment.jsp";
		String cookie ="";
		String param = "";
		String result ="";
		try {
			result = HttpRequest.sendGet(url, param,cookie);
			//    			System.out.println(result.indexOf("new RSAUtils.getKeyPair(\"10001\", \"\"\, "));
			System.out.println(result);
			int start =result.indexOf("RSAUtils.getKeyPair");
			int end = result.indexOf("RSAUtils.encryptedString");
			String temp = result.substring(start,end).replaceAll("\\s*", "");
			System.out.println(temp);
			String key = temp.substring(32, temp.length()-15);
			return key;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
}
