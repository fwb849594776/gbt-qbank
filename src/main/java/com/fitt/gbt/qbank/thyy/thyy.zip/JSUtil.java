package com.fitt.gbt.qbank.thyy;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import java.io.FileReader;
import java.io.IOException;

public class JSUtil {

    public static void main(String[] arg) throws IOException {

        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("js");

        try {
            String path = ExecuteScript.class.getResource("").getPath();
            System.out.println(path);
            // FileReader的参数为所要执行的js文件的路径
            //            engine.eval(new FileReader(path + "test.js"));
            engine.eval(new FileReader(path + "aes.js"));
            if (engine instanceof Invocable) {
                Invocable invocable = (Invocable)engine;
                System.out.println(invocable.invokeFunction("add",
                    "bf663caa49b6482b7b5934c60fd05a5163cf9ce072156392a161103b7ebb184c7f5d468662b0dfa092e30adc4f9c7a2ecd0ee39ef219c5dc3f44bc006749b4cbabe30fa50e3e77d49677f602c160d776e9cb4cb96d64835b35bc714a39f2bcd6170b17391dcaf15bae0d83d651ed579280d27279649e6cb2e3d8b8654b83f21d",
                    "23"));
                //              invocable.invokeMethod("RSAUtils", "10001", "1",
                // "bf663caa49b6482b7b5934c60fd05a5163cf9ce072156392a161103b7ebb184c7f5d468662b0dfa092e30adc4f9c7a2ecd0ee39ef219c5dc3f44bc006749b4cbabe30fa50e3e77d49677f602c160d776e9cb4cb96d64835b35bc714a39f2bcd6170b17391dcaf15bae0d83d651ed579280d27279649e6cb2e3d8b8654b83f21d");
                //              System.out.println(invocable.invokeFunction("getKeyPair1", "10001", "1",
                // "bf663caa49b6482b7b5934c60fd05a5163cf9ce072156392a161103b7ebb184c7f5d468662b0dfa092e30adc4f9c7a2ecd0ee39ef219c5dc3f44bc006749b4cbabe30fa50e3e77d49677f602c160d776e9cb4cb96d64835b35bc714a39f2bcd6170b17391dcaf15bae0d83d651ed579280d27279649e6cb2e3d8b8654b83f21d"));
                //Methods executeMethod = invocable.getInterface(Methods.class);
                //System.out.println("executeMethod = " + executeMethod);
                //              System.out.println(executeMethod.add("1", "2"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}