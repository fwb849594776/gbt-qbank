package com.fitt.gbt.qbank.thyy;

import com.alibaba.fastjson.JSONObject;
import com.fitt.gbt.qbank.pyyy.FileUtils;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;

/**
 * 抢技术入户预约号小程序 抢指定日期与时间段的号，不查询是否有空号，直接提交预约申请。
 *
 * @author kuangcl
 */
public class RecordFixed1 {
    private static final String SUBMIT_INFO_URL = "http://thzwb.thnet.gov.cn/appointment/getOrderServiceItem.action";
    private static final String COOKIES
        = "JSESSIONID=AFC9D279E1EFC0349012E45A291D671E; Hm_lvt_e7d4cfc620a3c5671317bc61d90cfb31=1539350471,"
        + "1539411570,1539411582,1539411601; Hm_lpvt_e7d4cfc620a3c5671317bc61d90cfb31=1539411631";

    /**
     * @param args
     */
    public static void main(String[] args) {
        RecordFixed1 rc = new RecordFixed1();
        //循环时间段提交预约请求
        rc.loopSubmitByTime(rc);
        //循环固定信息提交预约请求
        //		rc.loopSubmitFixedInfo(rc);
        //定时开始循环时间段提交预约请求
        //		rc.timer4(rc);
    }

    /**
     * 通过循环可预约时间段来提交预约请求
     *
     * @param rc
     */
    private void loopSubmitByTime(RecordFixed1 rc) {
        List<String> allTimes = rc.getTimes();
        while (true) {
            for (String time : allTimes) {
                try {
                    if (rc.submit("2018-11-06", time)) {
                        System.exit(0);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    //					loopSubmitByTime(rc);
                }
            }
        }
    }

    /**
     * 循环提交固定的时间段预约信息
     *
     * @param rc
     */
    private void loopSubmitFixedInfo(RecordFixed1 rc) {
        while (true) {
            if (rc.submit("2018-11-07", "10:30--12:00")) {
                break;
            }
        }
    }

    private boolean submit(String date, String time) {
        long start = System.currentTimeMillis();
        String info = "日期:" + date + ",时间：" + time + " 有号";
        Map<String, String> params = new HashMap<String, String>();
        params.put("service_item_code", "7008");
        params.put("time", time);
        params.put("predate", date);
        String param = getParams(params);
        System.out.println((System.currentTimeMillis()) - start);
        long start1 = System.currentTimeMillis();
        String submitResult = HttpRequest.sendPost(SUBMIT_INFO_URL, param, COOKIES);
        System.out.println((System.currentTimeMillis()) - start1);
        //预约结果
        JSONObject resultObject = JSONObject.parseObject(submitResult);
        System.out.println("date ：" + date + ",time=" + time);
        System.out.println(submitResult);
        // 成功
        if ("Y".equals(resultObject.get("is_order"))) {
            System.out.println("@@@@@@@请求参数：" + param);
            System.out.println(info + ",预约成功！！！RecordFixed1提交信息：" + param);
            FileUtils.writeToFile2(info + ",预约成功！！！" + RecordFixed1.class + "信息：" + param);
            sendMailNotice(info + ",预约成功！！！RecordFixed1提交信息：" + param);
            return true;
        }
        return false;
    }

    /**
     * 获取一天之内可预约的时间段
     *
     * @return
     */
    private List<String> getTimes() {
        List<String> times = new ArrayList<String>();
        times.add("14:00--15:00");
        times.add("10:30--12:00");
        times.add("16:00--17:30");
        times.add("08:30--09:30");
        times.add("09:30--10:30");
        times.add("15:00--16:00");
        return times;
    }

    /**
     * 定时开始循环时间段提交预约请求
     *
     * @param rc
     */
    public void timer4(final RecordFixed1 rc) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 23); // 控制时
        calendar.set(Calendar.MINUTE, 56);       // 控制分
        calendar.set(Calendar.SECOND, 57);       // 控制秒

        Date time = calendar.getTime();         // 得出执行任务的时间,此处为今天的23：59：58
        final List<String> allTimes = rc.getTimes();
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                while (true) {
                    for (String time : allTimes) {
                        if (rc.submit("2018-07-11", time)) {
                            System.exit(0);
                        }
                    }
                    //        			if(rc.submit("2018-07-06", "09:30--10:30")){
                    //        				System.exit(0);
                    //        			}
                    if ("2018-06-08 00:06".equals(sdf.format(new Date()))) {
                        System.exit(0);
                    }
                    //    				try {
                    //						Thread.sleep(1000);
                    //					} catch (InterruptedException e) {
                    //						e.printStackTrace();
                    //					}
                }
            }
        }, time);
    }

    /**
     * 发送邮件通知
     */
    private void sendMailNotice(String content) {
        // 收件人电子邮箱
        String to = "kuangcl@excellence.com.cn";

        // 发件人电子邮箱
        String from = "kuangchenglong@yeah.net";

        // 指定发送邮件的主机为 localhost
        String host = "smtp.yeah.net";

        // 获取系统属性
        Properties properties = System.getProperties();

        // 设置邮件服务器
        properties.setProperty("mail.smtp.host", host);
        properties.put("mail.smtp.auth", "true");
        properties.setProperty("mail.user", "kuangchenglong");
        properties.setProperty("mail.password", "chenglong33");

        // 获取默认session对象
        Session session = Session.getDefaultInstance(properties, new Authenticator() {
            public PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("kuangchenglong", "chenglong33"); //发件人邮件用户名、密码
            }
        });
        try {
            // 创建默认的 MimeMessage 对象
            MimeMessage message = new MimeMessage(session);

            // Set From: 头部头字段
            message.setFrom(new InternetAddress(from));

            // Set To: 头部头字段
            message.addRecipient(Message.RecipientType.TO,
                new InternetAddress(to));

            // Set Subject: 头部头字段
            message.setSubject("有号了");

            // 设置消息体
            message.setText(content);

            // 发送消息
            Transport.send(message);
            System.out.println("Sent message successfully....");
        } catch (MessagingException mex) {
            mex.printStackTrace();
        }
    }

    /**
     * 获取请求参数
     *
     * @param conds
     * @return
     */
    private String getParams(Map<String, String> conds) {
        StringBuffer param = new StringBuffer();
        //"certificate":perID,"phone":telpNum,"service_item_code":service_item_code,"time":is_free,"predate":apDate,
        // "service_item_name":service_item_name,"address":address,"addressMsg":addressMsg,
        // "addressPhone":addressPhone,"org_code":org_code
        //杨小红
        String modulus = KeyUtil.getModulus(COOKIES);
        //		String modulus =
        // "9e8367f9a21bb624d12e1fdd14ec0382f6ce2046a820a2d8b6d743ec8610390d6950253d41fdaf587ba34c6b34cbb88171c5e40ea20424b01d0e0c926a80862f1d88e364313ccede8c423b3a0176e4246055ccf039f684116f349cc83ef2d60c48fc000092fb525f1f589f4ab49c4bad841867a6ca6f12b6600bfe37616e5693";
        String certificate = "44090219790510402X";
        certificate = EncryptUtil.getEncryptString(modulus, certificate);//OK
        String phone = "15521246116";
        //		String phone = "18102247139";
        phone = EncryptUtil.getEncryptString(modulus, phone);//OK
        String service_item_code = (String)conds.get("service_item_code");
        service_item_code = EncryptUtil.getEncryptString(modulus, service_item_code);//OK
        String time = (String)conds.get("time");
        time = EncryptUtil.getEncryptString(modulus, time);//OK
        String predate = (String)conds.get("predate");
        predate = EncryptUtil.getEncryptString(modulus, predate);//OK
        //		String service_item_name = "技师（含紧缺工种）人才引进";
        String service_item_name = "";//OK,网页上面也是为空的
        String address = "";
        String addressMsg = "";
        try {
            address = java.net.URLEncoder.encode("天河北路894号（咨询电话：020-38470847）", "UTF-8");
            address = EncryptUtil.getEncryptString(modulus, address);//OK
            addressMsg = java.net.URLEncoder.encode("3", "UTF-8");
            addressMsg = EncryptUtil.getEncryptString(modulus, addressMsg);//OK
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        //		String address = "天河北路894号（咨询电话：020-38470847）";
        //		String addressMsg = "3";
        //		address = initData(encodeURI(address));
        //		addressMsg = initData(encodeURI(addressMsg));
        //		String addressPhone = "37690333";//网页上面没有提交这个参数了
        //		addressPhone = EncryptUtil.getEncryptString(modulus, addressPhone);
        String org_code = "G34014976";
        org_code = EncryptUtil.getEncryptString(modulus, org_code);//OK
        String regCode = "121897";//短信验证码
        regCode = EncryptUtil.getEncryptString(modulus, regCode);//OK
        String regNumber = "T2OQD";//图片验证码
        regNumber = EncryptUtil.getEncryptString(modulus, regNumber);//OK
        param.append("certificate=").append(certificate);
        param.append("&phone=").append(phone);
        param.append("&service_item_code=").append(service_item_code);
        param.append("&time=").append(time);
        param.append("&predate=").append(predate);
        param.append("&service_item_name=").append(service_item_name);
        param.append("&address=").append(address);
        param.append("&addressMsg=").append(addressMsg);
        //		param.append("&addressPhone=").append(addressPhone);
        param.append("&org_code=").append(org_code);
        param.append("&regCode=").append(regCode);
        param.append("&regNumber=").append(regNumber);
        //		System.out.println(param);
        return param.toString();
    }
}
