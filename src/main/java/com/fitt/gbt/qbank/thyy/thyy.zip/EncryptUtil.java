package com.fitt.gbt.qbank.thyy;

import java.io.FileReader;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class EncryptUtil {
    public static String getEncryptString(String modulus,String obj){
        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("js");
        try {
            String path = ExecuteScript.class.getResource("").getPath();
            //            System.out.println(path);
            // FileReader的参数为所要执行的js文件的路径
            //            engine.eval(new FileReader(path + "test.js"));
            engine.eval(new FileReader(path + "AES.js"));
            if (engine instanceof Invocable) {
                Invocable invocable = (Invocable) engine;
                String result = invocable.invokeFunction("getEncryptString",modulus,obj).toString();
                //              System.out.println(invocable.invokeFunction("add", "bf663caa49b6482b7b5934c60fd05a5163cf9ce072156392a161103b7ebb184c7f5d468662b0dfa092e30adc4f9c7a2ecd0ee39ef219c5dc3f44bc006749b4cbabe30fa50e3e77d49677f602c160d776e9cb4cb96d64835b35bc714a39f2bcd6170b17391dcaf15bae0d83d651ed579280d27279649e6cb2e3d8b8654b83f21d","23"));
                return result;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
}
