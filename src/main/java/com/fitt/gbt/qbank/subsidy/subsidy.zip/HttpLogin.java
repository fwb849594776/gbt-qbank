/*
 * Copyright (c) 2018 by Alibaba.inc All rights reserved
 */
package com.fitt.gbt.qbank.subsidy;

/**
 * @author : <a href="mailto:congchun.zcc@gmail.com">congchun.zcc</a>
 * @version : 1.0.0
 * @descripiton : Http模拟Ajax登录
 * @since : 2018/10/16
 */
public class HttpLogin {
    public static void main(String[] args) {
        String loginUrl = "";

    }
}
