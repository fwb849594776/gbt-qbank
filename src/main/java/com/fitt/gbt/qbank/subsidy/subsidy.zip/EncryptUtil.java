/*
 * Copyright (c) 2018 by Alibaba.inc All rights reserved
 */
package com.fitt.gbt.qbank.subsidy;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import java.io.FileReader;

/**
 * @author : <a href="mailto:congchun.zcc@gmail.com">congchun.zcc</a>
 * @version : 1.0.0
 * @descripiton : 加密方法
 * @since : 2018/10/17
 */
public class EncryptUtil {
    /**
     * 加密JS文件路径
     */
    public static final String encrptyFilePath
        = "D:\\workspace_self\\gbt-qbank\\src\\main\\java\\com\\fitt\\gbt\\qbank\\subsidy\\encrypt.js";

    /**
     * 获取JS执行引擎
     *
     * @return ScriptEngine
     */
    public static ScriptEngine getScriptEngine() {
        ScriptEngine engine = null;
        try {
            ScriptEngineManager manager = new ScriptEngineManager();
            engine = manager.getEngineByName("javascript");
            FileReader reader = new FileReader(encrptyFilePath);
            engine.eval(reader);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return engine;
    }

    /**
     * 执行JS函数
     *
     * @param jsFunction Javascript函数名
     * @param params     参数列表
     * @return Object
     */
    public static Object invokeFunction(String jsFunction, Object... params) {
        Object result = null;
        try {
            Invocable invocable = (Invocable)getScriptEngine();
            result = invocable.invokeFunction(jsFunction, params);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 加密
     *
     * @param salt     盐值
     * @param password 密码
     * @return String
     */
    public static String encrypt(String salt, String password) {
        return (String)invokeFunction("encrypt", salt, password);
    }

    /**
     * 转成16进制
     *
     * @param content 原始内容
     * @return String
     */
    public static String stringToHex(String content) {
        return (String)invokeFunction("stringToHex", content);
    }

    public static void main(String[] args) {
        // 3130353a3231303a36303a3139343a33383a3231343a3131393a3232363a3135393a3139333a3138333a3132393a3139343a3130303a343a313831
        String data = stringToHex(encrypt("5835931", "dc201809"));
        System.out.println(data);
    }
}
